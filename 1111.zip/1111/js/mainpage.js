function moveDetail(num){
    localStorage.setItem('postNum', num);
    window.location.href = 'promotionDetail.html';
}