window.onload = function () {
    var postNum = localStorage.getItem('postNum')
}
