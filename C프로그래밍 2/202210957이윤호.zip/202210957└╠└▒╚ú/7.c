#include <stdio.h>

int main (void)
{
	for(int i ='A';i<='Z';i++)	/*print alphabet*/
		printf("%c%c\t",i+32,i);/*lower and upper*/
	}
}
